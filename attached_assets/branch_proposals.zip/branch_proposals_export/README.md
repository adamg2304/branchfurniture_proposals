# Branch Proposals — Quote Viewer

A tokenised, client-facing quote page for Branch Furniture, powered by HubSpot live data.

## Architecture

```
artifacts/api-server/   Express API (Node.js / TypeScript)
artifacts/quote-viewer/ Client-facing quote page (vanilla HTML/JS, no framework)
```

## How it works

1. A rep sets a `quote_link_token` custom property on a HubSpot quote.
2. The tokenised URL is sent to the client: `/api/q/{quoteId}-{token}`
3. The API server validates the token, fetches the full quote from HubSpot (deal → line items → contact / company / owner), injects `window.QUOTE` into the HTML template, and serves it.  The browser never touches HubSpot directly.
4. The client can adjust quantities, then accept via `POST /api/q/{quoteId}/accept`, which writes a signature audit note back to HubSpot and updates the quote status to CLOSED.

## Environment variables

| Variable | Required | Description |
|---|---|---|
| `HUBSPOT_PRIVATE_APP_TOKEN` | ✅ | HubSpot private app token (needs quotes, contacts, companies, owners, deals, notes scopes) |
| `ZAPIER_WEBHOOK_URL` | optional | Fires on quote acceptance |
| `PORT` | ✅ | Port for the API server |

## Running locally

```bash
# Install
pnpm install

# API server (dev — rebuilds on start)
cd artifacts/api-server
pnpm dev

# Quote viewer (static dev preview — no HubSpot needed)
cd artifacts/quote-viewer
pnpm dev
```

## Key files

| File | Purpose |
|---|---|
| `api-server-src/lib/hubspot.ts` | All HubSpot API calls + token validation + payload builder |
| `api-server-src/routes/quote.ts` | `GET /api/q/:slug` — serves the quote page |
| `api-server-src/routes/accept.ts` | `POST /api/q/:quoteId/accept` — records acceptance |
| `api-server-src/templates/quote-template.html` | The quote page (same as `quote-viewer/index.html`) |
| `quote-viewer/public/quote-sample.js` | Dev-only sample data (Chai Travel) |
